export const Buttons = [// {
  //   id: 'Top of Page',
  //   icon: "fas fa-arrow-up"
  // },
  // {
  //   id: 'Middle of Page',
  //   icon: "fas fa-arrow-right"
  // },
  // {
  //   id: 'Bottom of Page',
  //   icon: "fas fa-arrow-down"
  // },
  // {
  //   id: 'Checkbox',
  //   icon: "far fa-check-square"
  // },
  // {
  //   id: 'Calculator',
  //   icon: "fas fa-calculator"
  // },
  // {
  //   id: 'Todo',
  //   icon: "fas fa-list-ul"
  // },
  // {
  //   id: 'Content',
  //   icon: "fas fa-align-left"
  // }
];